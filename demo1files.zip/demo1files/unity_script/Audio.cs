using UnityEngine;
using System.Collections;
using System.IO.Ports;

public class Audio : MonoBehaviour
{
    // public variables for drum sounds and drum audio source
    public AudioClip[] drumSounds; // array of different drum sounds clips
    public AudioSource drumPlayer; // audio source object for playing drum sounds

    // replace COM3 with the COM port that you're using
    // if you are using a Mac, replace with either /dev/ttyUSBX or /dev/ttyACMX
    private static string portName = "COM3";
    private static int baudRate = 9600;

    // port to listen for Aruino serial output (change "COM3" your respective port)
    private SerialPort port = new SerialPort(@"\\.\" + portName, baudRate);

    // public variables for background music
    public AudioClip[] songs;       // array of music track clips
    public AudioSource musicPlayer; // audio source object for playing background music

    private bool playing = false;

    // Initialization
    void Start() {
        port.Open();
        port.ReadTimeout = 25;
    }

    // Update called once per frame
    void Update() {

        // code to play sounds based on joystick command
        if (port.IsOpen) {
            try {
                string serialValue = port.ReadLine(); // read string from serial port output
                Debug.Log(serialValue);

                if (serialValue == "LEFT") {               // if the string "LEFT" is read from serial output (written by Arduino)

                    drumPlayer.clip = drumSounds[0]; // set the clip to play to be the first clip in drum sounds array
                    drumPlayer.Play();               // play the clip

                } else if (serialValue == "RIGHT") {

                    drumPlayer.clip = drumSounds[1];
                    drumPlayer.Play();

                } else if (serialValue == "DOWN") {

                    drumPlayer.clip = drumSounds[2];
                    drumPlayer.Play();

                } else if (serialValue == "UP") {

                    drumPlayer.clip = drumSounds[3];
                    drumPlayer.Play();

                } else if (serialValue == "BUTTON") { // if the joystick button is pressed, play or stop music

                    if (!playing) {
                        Debug.Log("Play");

                        musicPlayer.clip = songs[0];
                        musicPlayer.Play();

                        playing = true;
                    } else {
                        Debug.Log("Stop");

                        musicPlayer.Stop();

                        playing = false;
                    }
                }
            } catch (System.Exception) {
            }
        }
    }
}